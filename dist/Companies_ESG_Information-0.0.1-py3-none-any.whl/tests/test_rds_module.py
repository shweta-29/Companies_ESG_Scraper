''' This module contains a class to test the rds_module '''
import unittest

from project.rds_uploader.rds_module import RdsUploader


class RDSUploaderTestCase(unittest.TestCase):

    def setUp(self):
        username = input('Username : ')
        password = input('Password : ')
        self.rdsuploader = RdsUploader(
            'postgresql', 'psycopg2', 'aicoredb.cqozfzbqiixg.eu-west-2.rds.\
                amazonaws.com', 5432, 'postgres', 'postgres', 'shweta20')

    def test_init(self):
        expected_value = 'Engine(postgresql+psycopg2://postgres:***@aicoredb.\
            cqozfzbqiixg.eu-west-2.rds.amazonaws.com:5432/postgres)'
        actual_value = self.rdsuploader.engine
        print(actual_value)
        self.assertEqual(expected_value, actual_value)


if __name__ == '__main__':
    unittest.main()
#'postgres', 'shweta20'